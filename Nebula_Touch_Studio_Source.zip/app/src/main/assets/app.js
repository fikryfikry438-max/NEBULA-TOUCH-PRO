const $=id=>document.getElementById(id);
const sliders=['smooth','track','motion'];
const defaults=[65,55,40];
function setValues(values){sliders.forEach((id,i)=>{$(id).value=values[i];$(id+'Val').textContent=values[i]+'%'});document.querySelectorAll('.preset').forEach(p=>p.classList.toggle('selected',p.dataset.values===values.join(',')))}
sliders.forEach(id=>$(id).addEventListener('input',()=>{$(id+'Val').textContent=$(id).value+'%';document.querySelectorAll('.preset').forEach(p=>p.classList.remove('selected'))}));
document.querySelectorAll('.preset').forEach(p=>p.addEventListener('click',()=>setValues(p.dataset.values.split(',').map(Number))));
$('save').addEventListener('click',()=>{const values=sliders.map(id=>Number($(id).value));try{localStorage.setItem('nebula-profile',JSON.stringify(values));}catch(e){}$('toast').textContent='✓ Profile saved on this device';});
$('reset').addEventListener('click',()=>{setValues(defaults);$('toast').textContent='Default profile restored';});
try{const saved=JSON.parse(localStorage.getItem('nebula-profile'));if(Array.isArray(saved)&&saved.length===3)setValues(saved)}catch(e){}
document.querySelectorAll('.navbtn').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('.navbtn').forEach(b=>b.classList.toggle('active',b===btn));document.querySelectorAll('.page').forEach(p=>p.classList.add('hidden'));$('page-'+btn.dataset.page).classList.remove('hidden')}));
let hits=0,left=30,loop=null,best=0,running=false;
function placeTarget(){const a=$('arena'),t=$('target');const maxX=Math.max(0,a.clientWidth-54),maxY=Math.max(0,a.clientHeight-54);t.style.left=(8+Math.random()*Math.max(1,maxX-16))+'px';t.style.top=(8+Math.random()*Math.max(1,maxY-16))+'px'}
function endTest(){running=false;clearInterval(loop);$('target').classList.add('hidden');$('stop').classList.add('hidden');$('start').classList.remove('hidden');$('arenaHint').classList.remove('hidden');$('arenaHint').innerHTML='TEST COMPLETE<br><small>'+hits+' successful taps</small>';best=Math.max(best,hits);$('best').textContent=best}
$('start').addEventListener('click',()=>{if(running)return;running=true;hits=0;left=30;$('hits').textContent='0';$('timer').textContent='30s';$('arenaHint').classList.add('hidden');$('target').classList.remove('hidden');$('start').classList.add('hidden');$('stop').classList.remove('hidden');placeTarget();loop=setInterval(()=>{left--; $('timer').textContent=left+'s';if(left<=0)endTest()},1000)});
$('stop').addEventListener('click',endTest);
$('target').addEventListener('click',()=>{if(!running)return;hits++;$('hits').textContent=hits;placeTarget()});
