# Nebula Touch Studio — Android source project

This is an original, safe recreation inspired by the general dark/neon utility style of the supplied APK. It is not the original app and does not contain its proprietary code or assets.

## Included
- Dark/neon responsive UI
- Local sensitivity preference sliders and presets
- Save/reset profile locally
- Touch Lab practice minigame
- Android WebView wrapper project

## Build APK
1. Open this folder in Android Studio.
2. Allow Gradle sync (Android Gradle Plugin 8.6.1, SDK 35).
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

No game automation, aimbot, headlock, macro injection, or modification of other apps is included. Slider values are local preferences only; they do not change Android's system touch sensitivity.
